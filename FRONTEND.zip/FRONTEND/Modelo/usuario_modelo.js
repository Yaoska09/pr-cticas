class usuario_modelo {
    constructor(nombre, clave) {
        this.nombre = nombre;
        this.clave = clave;
    }
}

module.exports = usuario_modelo;
